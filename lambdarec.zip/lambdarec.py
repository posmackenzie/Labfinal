import os
import json

def handler(event, context):
    print("Event: {}".format(event))   